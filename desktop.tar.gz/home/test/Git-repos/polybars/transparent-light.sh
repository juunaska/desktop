polybar -r -c ~/.config/polybar/transparent-light.ini &
