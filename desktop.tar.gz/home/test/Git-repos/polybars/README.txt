put this dir to home dir
