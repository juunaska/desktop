polybar -r -c ~/.config/polybar/blue.ini &
