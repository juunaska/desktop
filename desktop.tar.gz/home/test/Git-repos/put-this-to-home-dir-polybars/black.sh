polybar -r -c ~/.config/polybar/black.ini &
