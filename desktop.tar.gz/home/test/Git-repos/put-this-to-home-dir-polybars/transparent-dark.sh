polybar -r -c ~/.config/polybar/transparent-dark.ini &
