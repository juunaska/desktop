exec /home/test/.config/bspwm/bspwmrc
